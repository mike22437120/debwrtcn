/* include/version.h */
#define CONFIG_SND_VERSION "1.0.22.1"
#define CONFIG_SND_DATE ""
