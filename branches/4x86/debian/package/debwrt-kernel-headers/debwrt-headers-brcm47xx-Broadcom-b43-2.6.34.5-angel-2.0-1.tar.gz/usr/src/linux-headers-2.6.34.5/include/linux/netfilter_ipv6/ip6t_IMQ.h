#ifndef _IP6T_IMQ_H
#define _IP6T_IMQ_H

/* Backwards compatibility for old userspace */
#include <linux/netfilter/xt_IMQ.h>

#define ip6t_imq_info xt_imq_info

#endif /* _IP6T_IMQ_H */

